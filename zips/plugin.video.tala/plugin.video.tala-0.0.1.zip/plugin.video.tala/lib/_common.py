import base64
import fnmatch
import gzip
import os
import re
import shutil
import sys
import time
import requests
import urllib
import zipfile
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from datetime import date,datetime,timedelta
from dateutil import parser as dparser

#from resources.lib.modules._addon import *
from lib._addon import *


GetDigit = lambda x: int(filter(str.isdigit, x) or 0)


def addDir(name,url,mode,iconimage=addon_icon,fanart=addon_fanart,description='',date=None,genre='',isfolder=True,isplayable=False):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description ,'genre': genre,"dateadded": date} )
        liz.setProperty( "Fanart_Image", fanart )
        if isplayable:
        	liz.setProperty('IsPlayable','true')
        	isfolder = False
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isfolder)
        return ok

def CreateDir(folder_path):
	if not xbmcvfs.exists(folder_path):
			created = xbmcvfs.mkdir(folder_path)
			if created:
				Log('Directory Created {}'.format(folder_path))
			else:
				Log('Unable to create {}'.format(folder_path))
	else:
		Log('Directory {} already exists'.format(folder_path))

def CopyFile(src,dst):
	if os.path.exists(src):
		shutil.copy2(src, dst)
		Sleep(3)
		if PathExists(dst):
			Log('File {} copied to {}'.format(src,dst))
	else:
		Log('{} does not excist'.format(src))

def bsixfour(s):
	try:
		bs = base64.b64decode(s)
		return bs
	except TypeError:
		Log('s = {} TypeError = {}'.format(s,TypeError))
		return s
	except:
		Log('s = {} Unknown Error'.format(s))
		return s

def DateTimeDelta(date,h=0):
	newDT = date+timedelta(hours=h)
	return newDT

def DateTimeObject(date_str,df=False):
	DTO = dparser.parse(date_str,dayfirst=df)
	return DTO

def DateTimeNow():
	DTN = datetime.now()
	return DTN

def DateTimeStrp(dateString,fmt):
	DTS = datetime.strptime(dateString, fmt)
	return DTS

def DateTimeToday():
	DTT = datetime.today()
	return DTT

def DownloadFile(url,dst):
	file = requests.get(url, stream=True)
	dump = file.raw
	with open(dst, 'wb') as location:
		shutil.copyfileobj(dump, location)
	#urllib.urlretrieve(url,dst)
	#Sleep(3)
	if os.path.exists(dst):
		Log('File {} downloaded From {}'.format(dst,url))
	else:
		Log('File {} not downloaded From {}'.format(dst,url))

def ExtractZip(file,dst):
	if file.endswith('.zip'):
		z = zipfile.ZipFile(file)
		z.extractall(dst)
	elif file.endswith('.gz'):
		with gzip.open(file, 'r') as f_in, open(dst, 'wb') as f_out:
			shutil.copyfileobj(f_in, f_out)

def FileMod_dt(file):
	if PathExists(file):
		modTime = datetime.fromtimestamp(os.path.getmtime(file))
	else:
		modTime = datetime.fromtimestamp(0)
	return modTime

def FnMatch(string,regex):
	match = fnmatch.fnmatch(string,regex)
	return match

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def KeyBoard(msg,default='',hidden=False):
	text = ''
	kb = xbmc.Keyboard()
	kb.setDefault(default)
	kb.setHeading(msg)
	kb.setHiddenInput(hidden)
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
	return text

def Log(msg):
	if setting_true('debug'):
		from inspect import getframeinfo, stack
		fileinfo = getframeinfo(stack()[1][0])
		xbmc.log('*__{}__{}*{} Python file name = {} Line Number = {}'.format(addon_name,addon_version,msg,fileinfo.filename,fileinfo.lineno), level=xbmc.LOGNOTICE)
	else:pass

def Notify(title='',message='',times='',icon=''):
	if title == '':
		title = addon_name
	if times == '':
		times = '10000'
	if icon == '':
		icon = addon_icon
	Notification = 'XBMC.Notification({},{},{},{})'.format(title,message,times,icon)
	xbmc.executebuiltin(str(Notification))

def OpenSettings():
	addon.openSettings()

def PathExists(path):
	if os.path.exists(path):
		return True
	else:
		return False

def refresh_container():
	xbmc.executebuiltin("XBMC.Container.Refresh")

def ReplaceMulti(string,replace_items):
    #replace_items is a dict with keys {'to replace':'replacement'}
    String = re.compile('|'.join(replace_items.keys()))
    string = String.sub(lambda m:replace_items[m.group(0)],string)
    return string

def RemoveFormatting(label):
    label = re.sub(r"\[/?[BI]\]",'',label)
    label = re.sub(r"\[/?COLOR.*?\]",'',label)
    return label

def RunModule(url='',mode='',name='',description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+urllib.quote_plus(description)
	xbmc.executebuiltin('XBMC.RunPlugin({})'.format(u))

def Sleep(sec):
	time.sleep(sec)

def TimedeltaTotalSeconds(timedelta):
    return (
        timedelta.microseconds + 0.0 +
        (timedelta.seconds + timedelta.days * 24 * 3600) * 10 ** 6) / 10 ** 6

def update_container():
	xbmc.executebuiltin("XBMC.Container.Update")

class weekday(object):
    __slots__ = ["weekday", "n"]

    def __init__(self, weekday, n=None):
        self.weekday = weekday
        self.n = n

    def __call__(self, n):
        if n == self.n:
            return self
        else:
            return self.__class__(self.weekday, n)

    def __eq__(self, other):
        try:
            if self.weekday != other.weekday or self.n != other.n:
                return False
        except AttributeError:
            return False
        return True

    def __hash__(self):
        return hash((
          self.weekday,
          self.n,
        ))

    def __ne__(self, other):
        return not (self == other)

    def __repr__(self):
        s = ("MO", "TU", "WE", "TH", "FR", "SA", "SU")[self.weekday]
        if not self.n:
            return s
        else:
            return "%s(%+d)" % (s, self.n)
class XbmcPlayer(xbmc.Player):

    def __init__( self, *args, **kwargs ):
		xbmc.Player.__init__(self)
		self.is_active = True
		self.is_stopped = False
		self.urlplayed = False
		self.pdialogue=None
   
		
    def onPlayBackStarted( self ):
        Log("#Playback Started#")
        self.urlplayed = True
        self.is_stopped = False
            
    def onPlayBackEnded( self ):
        Log('PlayBack Ended')
        self.is_active = False
        self.is_stopped = True
        
    def onPlayBackStopped( self ):
        Log('Playback Stopped')
        self.is_active = False
        self.is_stopped = True
      
